import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import AdminPage from "./admin";
import QuizPage from "./quiz";
import ResultsPage from "./result";
import ClubPage from './ClubPage';
import SigPage from './SigPage';
import SigDetails from './SigDetails';

function App() {
    return (
        <Router>
            <Routes>
                <Route path="/admin" element={<AdminPage />} />
                <Route path="/quiz" element={<QuizPage />} />
                <Route path="/results" element={<ResultsPage />} />
                <Route path="/" element={<ClubPage />} />  {/* Change here */}
                <Route path="/sigs/:clubId" element={<SigPage />} />  {/* Change here */}
                <Route path="/sig-details/:sigId" element={<SigDetails />} />  {/* Change here */}
            </Routes>
        </Router>
    );
}

export default App;

