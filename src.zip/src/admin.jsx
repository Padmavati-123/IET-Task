import React, { useState } from "react";
import Axios from "axios";
import { useNavigate } from "react-router-dom";

const AdminPage = () => {
    const [question, setQuestion] = useState("");
    const [options, setOptions] = useState(["", "", "", ""]);
    const [correctOption, setCorrectOption] = useState("");
    const navigate = useNavigate();

    const addQuestion = () => {
        Axios.post("http://localhost:3006/admin", {
            question,
            option1: options[0],
            option2: options[1],
            option3: options[2],
            option4: options[3],
            correctOption
        }).then(() => {
            alert("Question added successfully!");
            setQuestion("");
            setOptions(["", "", "", ""]);
            setCorrectOption("");
        }).catch((error) => {
            console.error("Error adding question:", error);
        });
    };

    return (
        <div style={{ padding: "20px" }}>
            <h1>Admin Page</h1>
            <div>
                <input
                    type="text"
                    placeholder="Enter Question"
                    value={question}
                    onChange={(e) => setQuestion(e.target.value)}
                />
                <div>
                    {options.map((option, index) => (
                        <div key={index}>
                            <input
                                type="text"
                                placeholder={`Option ${index + 1}`}
                                value={option}
                                onChange={(e) => {
                                    const updatedOptions = [...options];
                                    updatedOptions[index] = e.target.value;
                                    setOptions(updatedOptions);
                                }}
                            />
                        </div>
                    ))}
                </div>
                <input
                    type="text"
                    placeholder="Enter Correct Answer"
                    value={correctOption}
                    onChange={(e) => setCorrectOption(e.target.value)}
                />
                <button onClick={addQuestion}>Add Question</button>
                <button onClick={() => navigate("/quiz")}>Start Quiz</button>
            </div>
        </div>
    );
};

export default AdminPage;
